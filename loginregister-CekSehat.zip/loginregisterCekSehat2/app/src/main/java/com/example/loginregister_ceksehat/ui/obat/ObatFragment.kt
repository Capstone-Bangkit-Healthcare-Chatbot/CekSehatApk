package com.example.loginregister_ceksehat.ui.obat

class ObatFragment {
}