package com.example.loginregister_ceksehat.ui.artikel

class ArtikelFragment {
}