package com.example.loginregister_ceksehat.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.loginregister_ceksehat.databinding.ItemArtikelBinding
import com.example.loginregister_ceksehat.data.response.ArtikelResponse

class ArtikelAdapter : RecyclerView.Adapter<ArtikelAdapter.ArtikelViewHolder>() {

    private var artikelList = mutableListOf<ArtikelResponse>()

    fun submitList(articles: List<ArtikelResponse>) {
        artikelList.clear()
        artikelList.addAll(articles)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArtikelViewHolder {
        val binding = ItemArtikelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ArtikelViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ArtikelViewHolder, position: Int) {
        holder.bind(artikelList[position])
    }

    override fun getItemCount(): Int = artikelList.size

    inner class ArtikelViewHolder(private val binding: ItemArtikelBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(article: ArtikelResponse) {
            binding.tvTitle.text = article.title
            binding.tvContent.text = article.content
        }
    }
}