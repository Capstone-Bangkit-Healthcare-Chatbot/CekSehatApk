package com.example.loginregister_ceksehat.ui.artikel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.loginregister_ceksehat.data.response.ArtikelResponse
import com.example.loginregister_ceksehat.data.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ArtikelViewModel : ViewModel() {

    private val _articles = MutableLiveData<List<ArtikelResponse>>()
    val articles: LiveData<List<ArtikelResponse>> get() = _articles

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    fun getArticles() {
        _isLoading.value = true
        ApiConfig.getApiService().getArticles().enqueue(object : Callback<List<ArtikelResponse>> {
            override fun onResponse(call: Call<List<ArtikelResponse>>, response: Response<List<ArtikelResponse>>) {
                if (response.isSuccessful) {
                    _articles.value = response.body()
                }
                _isLoading.value = false
            }

            override fun onFailure(call: Call<List<ArtikelResponse>>, t: Throwable) {
                _isLoading.value = false
            }
        })
    }
}
