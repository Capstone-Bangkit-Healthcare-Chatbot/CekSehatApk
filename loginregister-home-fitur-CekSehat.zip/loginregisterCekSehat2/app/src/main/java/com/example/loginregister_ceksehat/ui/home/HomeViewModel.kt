package com.example.loginregister_ceksehat.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.loginregister_ceksehat.data.model.NewsItem
import com.example.loginregister_ceksehat.data.repository.NewsRepository
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _newsList = MutableLiveData<List<NewsItem>>()
    val newsList: LiveData<List<NewsItem>> = _newsList

    init {
        fetchNews()
    }

    private fun fetchNews() {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val news = NewsRepository.getNews()  // Panggil API dari repository
                _newsList.value = news
            } catch (e: Exception) {
                _newsList.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }
}
