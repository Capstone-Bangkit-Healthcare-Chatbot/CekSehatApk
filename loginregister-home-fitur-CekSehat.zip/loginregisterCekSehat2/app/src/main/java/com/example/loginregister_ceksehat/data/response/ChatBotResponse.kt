package com.example.loginregister_ceksehat.data.response

import com.google.gson.annotations.SerializedName

data class ChatBotResponse(
    @SerializedName("response") val response: String
)
