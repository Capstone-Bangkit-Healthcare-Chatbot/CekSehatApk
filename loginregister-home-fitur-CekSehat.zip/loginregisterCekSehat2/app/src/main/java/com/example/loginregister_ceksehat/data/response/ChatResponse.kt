package com.example.loginregister_ceksehat.data.response

data class ChatResponse(
    val reply: String
)
