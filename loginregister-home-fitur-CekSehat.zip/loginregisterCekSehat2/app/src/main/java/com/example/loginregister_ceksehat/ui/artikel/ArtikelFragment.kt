package com.example.loginregister_ceksehat.ui.artikel

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.loginregister_ceksehat.adapter.ArtikelAdapter
import com.example.loginregister_ceksehat.databinding.FragmentArtikelBinding

class ArtikelFragment : Fragment() {
    private var _binding: FragmentArtikelBinding? = null
    private val binding get() = _binding!!
    private lateinit var artikelViewModel: ArtikelViewModel
    private lateinit var artikelAdapter: ArtikelAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentArtikelBinding.inflate(inflater, container, false)

        artikelViewModel = ViewModelProvider(this).get(ArtikelViewModel::class.java)

        setupRecyclerView()
        observeViewModel()

        artikelViewModel.getArticles() // Menggunakan getArticles sesuai ViewModel

        return binding.root
    }

    private fun setupRecyclerView() {
        artikelAdapter = ArtikelAdapter()
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = artikelAdapter
        }
    }

    private fun observeViewModel() {
        artikelViewModel.articles.observe(viewLifecycleOwner) { articles ->
            articles?.let {
                artikelAdapter.submitList(it)
            }
        }

        artikelViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
