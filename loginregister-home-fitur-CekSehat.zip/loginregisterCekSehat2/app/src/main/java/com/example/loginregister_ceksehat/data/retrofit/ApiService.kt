package com.example.loginregister_ceksehat.data.retrofit

import com.example.loginregister_ceksehat.data.response.ArtikelResponse
import com.example.loginregister_ceksehat.data.response.ChatBotResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface ApiService {
    @GET("articles")
    fun getArticles(): Call<List<ArtikelResponse>>

    @POST("chat")
    fun getChatResponse(@Query("message") message: String): Call<ChatBotResponse>
}
