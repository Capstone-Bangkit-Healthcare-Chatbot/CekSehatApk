package com.example.loginregister_ceksehat.data.response

import com.google.gson.annotations.SerializedName

data class ArtikelResponse(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String,
    @SerializedName("content") val content: String
)
