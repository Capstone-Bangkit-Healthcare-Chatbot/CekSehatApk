package com.example.loginregister_ceksehat.ui.chatbot

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.loginregister_ceksehat.data.response.ChatRequest
import com.example.loginregister_ceksehat.data.response.ChatResponse
import com.example.loginregister_ceksehat.data.retrofit.ApiConfig
import com.example.loginregister_ceksehat.databinding.FragmentChatbotBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChatBotFragment : Fragment() {

    private lateinit var binding: FragmentChatbotBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentChatbotBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup tombol kirim pesan
        binding.sendButton.setOnClickListener {
            val message = binding.messageInput.text.toString()

            if (message.isNotEmpty()) {
                sendMessageToChatBot(message)
                binding.messageInput.text.clear()
            } else {
                Toast.makeText(requireContext(), "Pesan tidak boleh kosong", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendMessageToChatBot(message: String) {

        val apiService = ApiConfig.getChatBotApiService()
        val chatRequest = ChatRequest(message)

        apiService.sendMessage(chatRequest).enqueue(object : Callback<ChatResponse> {
            override fun onResponse(call: Call<ChatResponse>, response: Response<ChatResponse>) {
                if (response.isSuccessful) {
                    val reply = response.body()?.reply
                    binding.textWelcome3.text = reply
                } else {
                    Toast.makeText(requireContext(), "Gagal mendapat balasan", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ChatResponse>, t: Throwable) {
                Toast.makeText(requireContext(), "Error: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
