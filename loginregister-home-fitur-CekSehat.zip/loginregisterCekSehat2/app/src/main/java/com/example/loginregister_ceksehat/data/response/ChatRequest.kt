package com.example.loginregister_ceksehat.data.response

data class ChatRequest(
    val message: String
)
